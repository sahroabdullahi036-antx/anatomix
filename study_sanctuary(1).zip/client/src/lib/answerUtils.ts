export const normalizeAnswer = (answer: string): string => {
  return answer.toLowerCase().replace(/[-\/]/g, '').trim();
};

export const checkAnswer = (userAnswer: string, correctAnswer: string): boolean => {
  return normalizeAnswer(userAnswer) === normalizeAnswer(correctAnswer);
};
